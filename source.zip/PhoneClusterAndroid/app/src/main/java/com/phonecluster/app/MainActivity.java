package com.phonecluster.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.InputType;

public class MainActivity extends Activity {
    private static final String PREFS = "phonecluster_prefs";
    private static final String KEY_URL = "dashboard_url";
    private LinearLayout root;
    private EditText urlInput;
    private WebView webView;
    private SharedPreferences prefs;
    private int bg = Color.rgb(10,15,24);
    private int panel = Color.rgb(17,26,39);
    private int green = Color.rgb(99,242,174);
    private int text = Color.rgb(234,241,250);
    private int muted = Color.rgb(157,176,199);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showConnectScreen();
    }

    private GradientDrawable rounded(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(14));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void showConnectScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(22));
        root.setBackgroundColor(bg);
        setContentView(root);

        TextView title = label("◈ PhoneCluster", 28, text);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);
        TextView sub = label("Two phones. One control plane.", 14, muted);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(5); sp.bottomMargin = dp(26);
        root.addView(sub, sp);

        TextView cardTitle = label("Connect to your dashboard", 18, text);
        cardTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(cardTitle);

        TextView help = label("Start PhoneCluster on a Debian or Termux device, then enter its LAN URL below.", 14, muted);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(8); hp.bottomMargin = dp(15);
        root.addView(help, hp);

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(text);
        urlInput.setHintTextColor(muted);
        urlInput.setHint("http://192.168.0.210:8787");
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setText(prefs.getString(KEY_URL, ""));
        urlInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        urlInput.setBackground(rounded(panel, Color.rgb(39,54,75)));
        root.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(52)));

        Button connect = new Button(this);
        connect.setText("CONNECT");
        connect.setTextColor(Color.rgb(6,32,21));
        connect.setAllCaps(false);
        connect.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        connect.setBackground(rounded(green, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.topMargin = dp(12);
        root.addView(connect, bp);
        connect.setOnClickListener(v -> connect());

        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                connect(); return true;
            }
            return false;
        });

        TextView note = label("Tip: use the IP address of the phone running the dashboard. Both devices must be on the same Wi-Fi. The dashboard token is entered in the web dashboard itself.", 13, muted);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(22);
        root.addView(note, np);

        TextView features = label("\nDASHBOARD FEATURES\n• Remote terminal\n• CPU / RAM / storage metrics\n• Node management\n• Docker / Podman controls where supported\n• Minecraft / MultiPaper setup notes", 14, text);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.topMargin = dp(18);
        features.setPadding(dp(14), dp(14), dp(14), dp(14));
        features.setBackground(rounded(panel, Color.rgb(39,54,75)));
        root.addView(features, fp);
    }

    private void connect() {
        String url = urlInput.getText().toString().trim();
        if (url.isEmpty()) { urlInput.setError("Enter dashboard URL"); return; }
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://" + url;
        if (url.endsWith("/")) url = url.substring(0, url.length()-1);
        prefs.edit().putString(KEY_URL, url).apply();
        hideKeyboard();
        showWeb(url);
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }

    private void showWeb(String url) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(5), dp(8), dp(5));
        bar.setBackgroundColor(panel);
        TextView brand = label("◈ PhoneCluster", 16, green);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        Button change = new Button(this);
        change.setText("Change");
        change.setAllCaps(false);
        change.setTextColor(text);
        change.setBackground(rounded(Color.rgb(38,56,79), 0));
        bar.addView(change);
        change.setOnClickListener(v -> showConnectScreen());
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(52)));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else showConnectScreen();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
