# PhoneCluster Android — mobile-friendly APK build

This is the Android wrapper for the PhoneCluster dashboard. It asks for your dashboard URL (for example `http://192.168.0.210:8787`) and opens it inside the app. The Python PhoneCluster service must still run separately on Debian/Linux or Termux.

## Build the APK from your phone (no Android Studio needed)

1. Sign in to GitHub in your mobile browser and create a **new empty repository**.
2. Upload the contents of this ZIP to the repository root. Make sure `.github/workflows/build-apk.yml` is included. If GitHub's web uploader hides `.github`, create/upload the workflow using GitHub's **Add file → Create new file** and name it `.github/workflows/build-apk.yml`, then paste its contents from this project.
3. Open the repository's **Actions** tab and select **Build PhoneCluster APK**.
4. Tap **Run workflow** (on the first run, GitHub may ask you to enable Actions).
5. When the run finishes green, open that run, scroll to **Artifacts**, and download `PhoneCluster-debug-APK`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/file manager.

Pushing the files to the `main` branch also triggers a build automatically. Builds run on GitHub's hosted runner; no SDK or compiler is needed on your phone. GitHub account and internet access are required.

## Local build alternative

Open this folder in Android Studio, install Android SDK Platform 35, then run `gradle assembleDebug` with Gradle 8.9 and Java 17.

## Security and limitations

- The APK is a WebView wrapper, not the Python server itself. Start the PhoneCluster service separately.
- The wrapper permits HTTP for local LAN URLs. Do not expose the dashboard to the public internet.
- The dashboard bearer token allows terminal command execution as the service user. Keep it private and use trusted Wi-Fi only.
